create table objectoriented(
	no			number(20) primary key,
	stu_number	varchar2(100),
   	regdate  	date
);

create sequence student_no_seq start with 1
increment by 1;

select * from OBJECTORIENTED;

drop table objectoriented;

insert into OBJECTORIENTED values(student_no_seq.NEXTVAL, '2013244093', sysdate);

