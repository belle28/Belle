create sequence MEMBER_SEQ_NO start with 1
increment by 1;

drop sequence MEMBER_ID;

create table student
(
	STUDENT_NO	INT				NOT NULL,
	NAME		nvarchar2(10)	NOT NULL,
	PASSWORD	VARCHAR(50)		NOT NULL,
	DEPARTMENT	VARCHAR(50)		NOT NULL,
	WORK_TYPE	INT				NOT NULL,
	PRIMARY KEY (STUDENT_NO)
);

INSERT INTO STUDENT VALUES(2013244093, '������', '11111', '��ǻ�Ͱ��а�', 1);
INSERT INTO PROFESSOR VALUES(1111111, 'Ȯ����', '11111', '��ǻ�Ͱ��а�', 2);

CREATE TABLE PROFESSOR
(
	PROFESSOR_NO	INT			NOT NULL,
	NAME		nvarchar2(10)	NOT NULL,
	PASSWORD	VARCHAR(50)		NOT NULL,
	DEPARTMENT	VARCHAR(50)		NOT NULL,
	WORK_TYPE	INT				NOT NULL,
	PRIMARY KEY (PROFESSOR_NO)
);


CREATE TABLE MEMBER
(
   MEMBER_ID      INT               NOT NULL,
   STUDENT_NO      INT               NOT NULL,
   NAME         nvarchar2(10)            NOT NULL,
   PASSWORD      VARCHAR(50)            NOT NULL,
   DEPARTMENT      VARCHAR(50)            NOT NULL,
   WORK_TYPE      INT               NOT NULL,
   PRIMARY KEY (MEMBER_ID)
);

INSERT INTO member VALUES('2014244070','�̼���','1234','��ǻ�Ͱ��а�','�л�');
INSERT INTO member VALUES('2013244093','������','1234','��ǻ�Ͱ��а�','�л�');

insert into member values(MEMBER_SEQ_NO.NEXTVAL, 2013244093, '������', '1234', '��ǻ�Ͱ��а�', 1);
insert into member values(MEMBER_SEQ_NO.NEXTVAL, 2014244070, '�̼���', '5678', '��ǻ�Ͱ��а�', 1);
insert into member values(MEMBER_SEQ_NO.NEXTVAL, 2013244102, '������', '3333', '��ǻ�Ͱ��а�', 1);
insert into member values(MEMBER_SEQ_NO.NEXTVAL, 2009244215, '�̹���', '4444', 'ȭ�а��а�', 1);
insert into member values(MEMBER_SEQ_NO.NEXTVAL, 2009232111, 'Ȳ��ȯ', '5555', '�����а�', 1);
INSERT INTO MEMBER VALUES(MEMBER_SEQ_NO.NEXTVAL, 2009224311, '������', '6666', 'ȭ�а��а�', 2);




drop table member;
drop table subject;
drop table MEMBER_REGISTERATION;
drop table MEMBER_ATTENDACNE;

create sequence SUBJECT_SEQ_NO start with 1
increment by 1;

CREATE TABLE SUBJECT
(
   SUBJECT_ID      INT               NOT NULL,
   NAME         nvarchar2(50)            NOT NULL,
   CLASS_ID      INT               NOT NULL,
   DAY         INT               NOT NULL,
   START_HOUR      INT               NOT NULL,
   START_MINUTE      INT               NOT NULL,
   END_HOUR      INT               NOT NULL,
   END_MINUTE      INT               NOT NULL,
   PRIMARY KEY (SUBJECT_ID)
);

INSERT INTO SUBJECT VALUES

INSERT INTO SUBJECT VALUES(SUBJECT_ID, 'NAME', CLASS_ID, DAY, START_HOUR, START_MINUTE, END_HOUR, END_MINUTE)
(1,'Spring', 401, 1, 9, 30, 10, 20),
(2,'ObjectOriented', 402, 1, 9, 30, 10, 20),
(3,'JSP/Servlet', 401, 1, 10, 30, 11, 20),
(4,'Android', 401, 1, 11, 30, 12, 20);

INSERT INTO SUBJECT VALUES(SUBJECT_SEQ_NO.NEXTVAL,'Android', 401, 1, 11, 30, 12, 20);

CREATE TABLE MEMBER_REGISTERATION
(
   MEMBER_ID         INT            NOT NULL,
   SUBJECT_ID         INT            NOT NULL,
   PRIMARY KEY (SUBJECT_ID, MEMBER_ID),
   FOREIGN KEY (MEMBER_ID) REFERENCES MEMBER (MEMBER_ID) ON DELETE CASCADE,
   FOREIGN KEY (SUBJECT_ID) REFERENCES SUBJECT (SUBJECT_ID) ON DELETE CASCADE
);

CREATE TABLE MEMBER_ATTENDACNE
(
   MEMBER_ID      INT               NOT NULL,
   SUBJECT_ID      INT               NOT NULL,
   WEEK         INT               NOT NULL,
   TAG_TIME      date            NOT NULL,
   ATTENDANCE_TYPE      INT               NOT NULL,
   PRIMARY KEY (MEMBER_ID, SUBJECT_ID),
   FOREIGN KEY (MEMBER_ID) REFERENCES MEMBER (MEMBER_ID) ON DELETE CASCADE,
   FOREIGN KEY (SUBJECT_ID) REFERENCES SUBJECT (SUBJECT_ID) ON DELETE CASCADE
);