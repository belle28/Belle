package com.chy.member.domain;

public class Professor extends Member {
	private int professorNo;
	private String proName;
	private String password;
	private String department;
	private int workType;

	public Professor(int professorNo, String proName, String password, String department, int workType) {
		super();
		this.professorNo = professorNo;
		this.proName = proName;
		this.password = password;
		this.department = department;
		this.workType = workType;
	}

	public Professor() {
		super();
	}

	public Professor(int professorNo, String proName, String password, String department) {
		super();
		this.professorNo = professorNo;
		this.proName = proName;
		this.password = password;
		this.department = department;
	}

	public int getProfessorNo() {
		return professorNo;
	}

	public void setProfessorNo(int professorNo) {
		this.professorNo = professorNo;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getWorkType() {
		return workType;
	}

	public void setWorkType(int workType) {
		this.workType = workType;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Professor [professorNo=");
		builder.append(professorNo);
		builder.append(", proName=");
		builder.append(proName);
		builder.append(", password=");
		builder.append(password);
		builder.append(", department=");
		builder.append(department);
		builder.append(", workType=");
		builder.append(workType);
		builder.append("]");
		return builder.toString();
	}
}
