package com.chy.member.domain;

public class Student extends Member {
	private int studentNo;
	private String name;
	private String password;
	private String department;
	private int workType;

	public Student(int studentNo, String name, String password, String department, int workType) {
		super();
		this.studentNo = studentNo;
		this.name = name;
		this.password = password;
		this.department = department;
		this.workType = workType;
	}

	public Student() {
		super();
	}

	public Student(int studentNo, String name, String password, String department) {
		super();
		this.studentNo = studentNo;
		this.name = name;
		this.password = password;
		this.department = department;
	}

	public int getStudentNo() {
		return studentNo;
	}

	public void setStudentNo(int studentNo) {
		this.studentNo = studentNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getWorkType() {
		return workType;
	}

	public void setWorkType(int workType) {
		this.workType = workType;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Student [studentNo=");
		builder.append(studentNo);
		builder.append(", name=");
		builder.append(name);
		builder.append(", password=");
		builder.append(password);
		builder.append(", department=");
		builder.append(department);
		builder.append(", workType=");
		builder.append(workType);
		builder.append("]");
		return builder.toString();
	}
}
