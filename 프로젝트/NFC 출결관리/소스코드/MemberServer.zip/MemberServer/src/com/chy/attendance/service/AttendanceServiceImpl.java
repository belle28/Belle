package com.chy.attendance.service;

import java.util.ArrayList;

import com.chy.attendance.dao.AttendanceDao;
import com.chy.attendance.dao.AttendanceDaoImpl;
import com.chy.attendance.domain.MemberAttendance;
import com.chy.attendance.domain.MemberRegisteration;
import com.chy.attendance.domain.Subject;
import com.chy.code.DayOfWeek;

public class AttendanceServiceImpl implements AttendanceService {
	AttendanceDao attendancedao = new AttendanceDaoImpl();

	@Override
	public Subject getSubject(int classId, String day, String time) {
		// Calendar calendar = Calendar.getInstance();
		// SimpleDateFormat dateFormat = new SimpleDateFormat("hhmm/E");
		//
		// String currentTime = dateFormat.format(calendar.getTime());
		// System.out.println("����ð� : " + currentTime);
		//
		// String[] currentTimes = currentTime.split("/");
		// int day1 = DayOfWeek.convert(currentTimes[1]).getCode();
		// int cTime = Integer.parseInt(currentTimes[0]);

		int dow = DayOfWeek.convert(day).getCode();
		System.out.println("AttendanceServiceImpl getSubject dow = " + dow);
		int cTime = Integer.parseInt(time);
		Subject subject = attendancedao.getSubject(classId, dow, cTime);
		return subject;
	}

	@Override
	public Subject getSubject(int professorNo) {
		return attendancedao.getSubject(professorNo);
	}

	@Override
	public boolean checkStudent(int stuNumber, int subjectId) {
		return attendancedao.checkStudent(stuNumber, subjectId);
	}

	@Override
	public int checkAttendance(Subject subject, int time) {
		int startTime = subject.getStartTime();
		System.out.println("Start Time = " + startTime);
		if (time >= startTime && time <= (startTime + 9)) {
			return 1;
		}
		return 2;
	}

	@Override
	public boolean insertAttendance(int stuNumber, int subjectId, String regDate, int tagTime, int AttendanceType,
			String Studentname) {
		return attendancedao.insertAttendance(stuNumber, subjectId, regDate, tagTime, AttendanceType, Studentname);
	}

	@Override
	public ArrayList<MemberAttendance> getCurrentAttendance(int subjectId, String currentTime) {
		return attendancedao.getCurrentAttendance(subjectId, currentTime);
	}

}
