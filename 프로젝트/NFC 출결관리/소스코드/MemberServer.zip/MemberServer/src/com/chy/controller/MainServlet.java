package com.chy.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.chy.attendance.domain.MemberAttendance;
import com.chy.attendance.domain.Subject;
import com.chy.attendance.service.AttendanceService;
import com.chy.attendance.service.AttendanceServiceImpl;
import com.chy.member.domain.Member;
import com.chy.member.domain.Professor;
import com.chy.member.domain.Student;
import com.chy.member.service.MemberService;
import com.chy.member.service.MemberServiceImpl;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	MemberService memberservice = new MemberServiceImpl();
	AttendanceService attendanceservice = new AttendanceServiceImpl();

	public MainServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");

		String action = request.getParameter("action");

		if (action.equals("insertStudent")) {
			boolean result = insertStudent(request, response);
			request.setAttribute("result", result);
			request.getRequestDispatcher("result/result.jsp").forward(request, response);
		} else if (action.equals("insertProfessor")) {
			boolean result = insertProfessor(request, response);
			request.setAttribute("result", result);
			request.getRequestDispatcher("result/result.jsp").forward(request, response);
		} else if (action.equals("login")) {
			Member member = login(request, response);
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println(new ObjectMapper().writeValueAsString(member));
			out.close();
		} else if (action.equals("leave")) {

		} else if (action.equals("updateMember")) {

		} else if (action.equals("check")) {
			boolean result = check(request, response);
			// Calendar calendar = Calendar.getInstance();
			// SimpleDateFormat dateFormat = new SimpleDateFormat("hhmm/E");
			// String currentTime = dateFormat.format(calendar.getTime());
			// System.out.println("����ð� : " + currentTime);
			request.setAttribute("result", result);
			request.getRequestDispatcher("result/resultLeave.jsp").forward(request, response);
		} else if (action.equals("attendanceList")) {
			ArrayList<MemberAttendance> attendanceArr = getCurrentAttendance(request, response);
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println(new ObjectMapper().writeValueAsString(attendanceArr));
			out.close();
		}
	}

	private ArrayList<MemberAttendance> getCurrentAttendance(HttpServletRequest request, HttpServletResponse response) {
		int professorNo = Integer.parseInt(request.getParameter("professorNo"));
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yy/MM/dd");
		String currentTime = dateFormat.format(calendar.getTime());
		System.out.println("currentTime = " + currentTime);
		Subject subject = attendanceservice.getSubject(professorNo);
		int subjectId = subject.getSubjectId();
		return attendanceservice.getCurrentAttendance(subjectId, currentTime);
	}

	private boolean check(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("studentName");
		String day = request.getParameter("day");
		String time = request.getParameter("time");

		int classId = Integer.parseInt(request.getParameter("classId"));
		Subject subject = attendanceservice.getSubject(classId, day, time);
		int subjectId = subject.getSubjectId();
		int stuNumber = Integer.parseInt(request.getParameter("studentNo"));
		boolean result = attendanceservice.checkStudent(stuNumber, subjectId);

		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");

		String regDate = dateFormat.format(calendar.getTime());
		// System.out.println("����ð� : " + currentTime);
		// String[] currentTimes = currentTime.split("/");
		// int day1 = DayOfWeek.convert(currentTimes[1]).getCode();
		// int cTime = Integer.parseInt(currentTimes[0]);

		int tagTime = Integer.parseInt(time);
		if (result) {
			int attendance = attendanceservice.checkAttendance(subject, Integer.parseInt(time));
			return attendanceservice.insertAttendance(stuNumber, subjectId, regDate, tagTime, attendance, name);
		} else {
			return false;
		}
	}

	private Member login(HttpServletRequest request, HttpServletResponse response) {
		int memberNo = Integer.parseInt(request.getParameter("memberNo"));
		String password = request.getParameter("password");
		return memberservice.login(memberNo, password);
	}

	private boolean insertStudent(HttpServletRequest request, HttpServletResponse response) {
		int studentNo = Integer.parseInt(request.getParameter("studentNo"));
		String name = request.getParameter("student_name");
		String password = request.getParameter("password");
		String department = request.getParameter("department");
		int workType = Integer.parseInt(request.getParameter("workType"));
		Student student = new Student(studentNo, name, password, department, workType);
		return memberservice.insertStudent(student);
	}

	private boolean insertProfessor(HttpServletRequest request, HttpServletResponse response) {
		int professorNo = Integer.parseInt(request.getParameter("professorNo"));
		String professorName = request.getParameter("professor_name");
		String password = request.getParameter("password");
		String department = request.getParameter("department");
		int workType = Integer.parseInt(request.getParameter("workType"));
		Professor professor = new Professor(professorNo, professorName, password, department, workType);
		return memberservice.insertProfessor(professor);
	}

	// private boolean insertMember(HttpServletRequest request,
	// HttpServletResponse response) {
	// String name = request.getParameter("name");
	// String password = request.getParameter("password");
	// int studentNo = Integer.parseInt(request.getParameter("studentNo"));
	// int workType = Integer.parseInt(request.getParameter("work"));
	// String department = request.getParameter("department");
	//
	// Member member = new Member(studentNo, name, password, department,
	// workType);
	// return memberservice.insertMember(member);
	// }

	// private Member searchMember(int studentNo) {
	// return memberservice.searchMember(studentNo);
	// }

	// private Member updateMember(HttpServletRequest request,
	// HttpServletResponse response) {
	// String name = request.getParameter("name");
	// String password = request.getParameter("password");
	// int studentNo = Integer.parseInt(request.getParameter("studentNo"));
	// int workType = Integer.parseInt(request.getParameter("work"));
	// String department = request.getParameter("department");
	// Member member = new Member(studentNo, name, password, department,
	// workType);
	// return memberservice.updateMember(member);
	// }
	//
	// private boolean deleteMember(HttpServletRequest request,
	// HttpServletResponse response) {
	// int studentNo = Integer.parseInt(request.getParameter("studentNo"));
	// return memberservice.deleteMember(studentNo);
	// }

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
