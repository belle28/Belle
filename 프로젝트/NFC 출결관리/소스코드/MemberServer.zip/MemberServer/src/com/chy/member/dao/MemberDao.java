package com.chy.member.dao;

import java.sql.Connection;

import com.chy.member.domain.Member;
import com.chy.member.domain.Professor;
import com.chy.member.domain.Student;

public interface MemberDao {
	// public boolean insertMember(Connection con, Member member);

	public boolean insertStudent(Student student);

	public boolean insertProfessor(Professor professor);

	// public Member serarchMember(int stu_number);

	public Student searchStudent(int studentNo);

	public Professor searchProfessor(int professorNo);

	// public Member updateMember(Member member);
	//
	// public boolean deleteMember(int stu_number);

}
