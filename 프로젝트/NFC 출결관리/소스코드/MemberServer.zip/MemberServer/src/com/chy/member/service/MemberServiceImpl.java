package com.chy.member.service;

import com.chy.member.dao.MemberDao;
import com.chy.member.dao.MemberDaoImpl;
import com.chy.member.domain.Member;
import com.chy.member.domain.Professor;
import com.chy.member.domain.Student;

public class MemberServiceImpl implements MemberService {

	MemberDao memberdao = new MemberDaoImpl();

	// @Override
	// public boolean insertMember(Member memeber) {
	// Connection con = null;
	// try {
	// con = DBUtil.getConnection();
	// boolean reuslt = memberdao.insertMember(con, memeber);
	// if (reuslt) {
	// return true;
	// } else {
	// return false;
	// }
	// } finally {
	// DBUtil.close(con);
	// }
	// }

	@Override
	public Member login(int memberNo, String password) {
		Student student = searchStudent(memberNo);
		Professor professor = searchProfessor(memberNo);
		if (student != null) {
			if (student.getPassword().equals(password))
				return student;
		}
		if (professor != null) {
			if (professor.getPassword().equals(password)) {
				return professor;
			}
		}
		return null;
	}

	// @Override
	// public Member searchMember(int stu_number) {
	// return memberdao.serarchMember(stu_number);
	// }

	@Override
	public Student searchStudent(int studentNo) {
		return memberdao.searchStudent(studentNo);
	}

	@Override
	public Professor searchProfessor(int professorNo) {
		return memberdao.searchProfessor(professorNo);
	}

	@Override
	public boolean insertStudent(Student student) {
		return memberdao.insertStudent(student);
	}

	@Override
	public boolean insertProfessor(Professor professor) {
		return memberdao.insertProfessor(professor);
	}

	// @Override
	// public boolean deleteMember(int stu_number) {
	// return memberdao.deleteMember(stu_number);
	// }
	//
	// @Override
	// public Member updateMember(Member member) {
	// return memberdao.updateMember(member);
	// }

}
