package com.chy.attendance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.chy.attendance.domain.MemberAttendance;
import com.chy.attendance.domain.Subject;
import com.chy.util.DBUtil;

public class AttendanceDaoImpl implements AttendanceDao {

	// �ð��񱳸� ���� ���������� �޾ƿ´�...
	@Override
	public Subject getSubject(int classId, int day, int currentTime) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int count = 0;
		try {
			con = DBUtil.getConnection();
			System.out.println("AttendanceDao getSubject...........");
			System.out.println("classId = " + classId);
			System.out.println("day = " + day);
			System.out.println("currentTime = " + currentTime);
			String sql = "select subject_id, subject_name, class_id, day, start_time, end_time, professor_no from subject where class_id = ? and day=? and start_time <= ? and end_time >= ?";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, classId);
			stmt.setInt(2, day);
			stmt.setInt(3, currentTime);
			stmt.setInt(4, currentTime);
			System.out.println("��������...........");
			rs = stmt.executeQuery();
			if (rs.next()) {
				System.out.println("count = " + count++);
				Subject subject = new Subject(rs.getInt("subject_id"), rs.getString("subject_name"),
						rs.getInt("class_id"), rs.getInt("day"), rs.getInt("start_time"), rs.getInt("end_time"),
						rs.getInt("professor_no"));
				System.out.println(subject.toString());
				return subject;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return null;
	}

	public Subject getSubject(int professorNo) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int count = 0;
		try {
			con = DBUtil.getConnection();
			String sql = "select subject_id, subject_name, class_id, day, start_time, end_time, professor_no from subject where professor_no=?";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, professorNo);
			rs = stmt.executeQuery();
			if (rs.next()) {
				Subject subject = new Subject(rs.getInt("subject_id"), rs.getString("subject_name"),
						rs.getInt("class_id"), rs.getInt("day"), rs.getInt("start_time"), rs.getInt("end_time"),
						rs.getInt("professor_no"));
				return subject;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return null;
	}

	// �ش� ���� �л��� �ִ��� ������ �޾ƿ´�..
	@Override
	public boolean checkStudent(int stuNumber, int subjectId) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = "select * from registeration where student_no=? and subject_id=?";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, stuNumber);
			stmt.setInt(2, subjectId);
			if (stmt.executeUpdate() > 0)
				return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return false;
	}

	// �������� ����� ����
	@Override
	public boolean insertAttendance(int stuNumber, int subjectId, String regDate, int tagTime, int attendanceType,
			String studentName) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = "insert into attendance values(ATTENDANCE_SEQ_NO.NEXTVAL,?,?,to_char(sysdate, 'yyyymmdd'),?,?,?)";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, stuNumber);
			stmt.setInt(2, subjectId);
			stmt.setInt(3, tagTime);
			stmt.setInt(4, attendanceType);
			stmt.setString(5, studentName);
			if (stmt.executeUpdate() > 0)
				return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}

	@Override
	public ArrayList<MemberAttendance> getCurrentAttendance(int subjectId, String currentTime) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		ArrayList<MemberAttendance> attendanceArr = new ArrayList<MemberAttendance>();
		int count = 0;
		try {
			con = DBUtil.getConnection();
			String sql = "select student_no, subject_id, NVL(reg_date, to_char(sysdate, 'yyyymmdd')) reg_date, tag_time, NVL(attendance_type, 0) attendance_type, student_name from registeration left outer join attendance using (student_no, subject_id,student_name) where subject_id=? and NVL(reg_date, to_char(sysdate, 'yyyymmdd'))=?";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, subjectId);
			stmt.setString(2, currentTime);
			rs = stmt.executeQuery();
			while (rs.next()) {
				attendanceArr.add(
						new MemberAttendance(rs.getInt("student_no"), rs.getInt("subject_id"), rs.getString("reg_date"),
								rs.getInt("tag_time"), rs.getInt("attendance_type"), rs.getString("student_name")));
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return attendanceArr;
	}

}
