package com.chy.code;

public enum DayOfWeek {
	NONE(0, "Null"),
	MON(1, "��"),
	THU(2, "ȭ"),
	WED(3, "��"),
	THR(4, "��"),
	FRI(5, "��");
	

	private int code;
	private String codeStr;

	private DayOfWeek(int code, String codeStr) {
		this.code = code;
		this.codeStr = codeStr;
	}

	public int getCode() {
		return code;
	}
	
	private String getCodeStr() {
		return codeStr;
	}


	public static DayOfWeek convert(String codeStr) {
		for (DayOfWeek item : DayOfWeek.values()) {
			if (codeStr.equals(item.getCodeStr())) {
				return item;
			}
		}

		return DayOfWeek.NONE;
	}

	

}
