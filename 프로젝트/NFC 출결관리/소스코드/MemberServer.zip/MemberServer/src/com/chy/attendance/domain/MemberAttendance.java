package com.chy.attendance.domain;

public class MemberAttendance {
	private int sutdentNo;
	private int subjectId;
	private String regDate;
	private int tagTime;
	private int attendanceType;
	private String studentName;

	public MemberAttendance() {
		super();
	}

	public MemberAttendance(int sutdentNo, int subjectId, String regDate, int tagTime, int attendanceType,
			String studentName) {
		super();
		this.sutdentNo = sutdentNo;
		this.subjectId = subjectId;
		this.regDate = regDate;
		this.tagTime = tagTime;
		this.attendanceType = attendanceType;
		this.studentName = studentName;
	}

	public int getSutdentNo() {
		return sutdentNo;
	}

	public void setSutdentNo(int sutdentNo) {
		this.sutdentNo = sutdentNo;
	}

	public int getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public int getTagTime() {
		return tagTime;
	}

	public void setTagTime(int tagTime) {
		this.tagTime = tagTime;
	}

	public int getAttendanceType() {
		return attendanceType;
	}

	public void setAttendanceType(int attendanceType) {
		this.attendanceType = attendanceType;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("MemberAttendance [sutdentNo=");
		builder.append(sutdentNo);
		builder.append(", subjectId=");
		builder.append(subjectId);
		builder.append(", regDate=");
		builder.append(regDate);
		builder.append(", tagTime=");
		builder.append(tagTime);
		builder.append(", attendanceType=");
		builder.append(attendanceType);
		builder.append(", studentName=");
		builder.append(studentName);
		builder.append("]");
		return builder.toString();
	}
}
