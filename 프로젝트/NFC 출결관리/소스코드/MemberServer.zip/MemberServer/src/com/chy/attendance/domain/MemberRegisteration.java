package com.chy.attendance.domain;

public class MemberRegisteration {
	private int subjectId;
	private int studentNo;

	public MemberRegisteration(int subjectId, int studentNo) {
		super();
		this.subjectId = subjectId;
		this.studentNo = studentNo;
	}

	public MemberRegisteration() {
		super();
	}

	public int getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}

	public int getStudentNo() {
		return studentNo;
	}

	public void setStudentNo(int studentNo) {
		this.studentNo = studentNo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("MemberRegisteration [subjectId=");
		builder.append(subjectId);
		builder.append(", studentNo=");
		builder.append(studentNo);
		builder.append("]");
		return builder.toString();
	}
}
