package com.chy.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.chy.member.domain.Member;
import com.chy.member.domain.Professor;
import com.chy.member.domain.Student;
import com.chy.util.DBUtil;

public class MemberDaoImpl implements MemberDao {

	// @Override
	// public boolean insertMember(Connection con, Member member) {
	// PreparedStatement stmt = null;
	// try {
	// String sql = "insert into member values(?,?,?,?,?)";
	// stmt = con.prepareStatement(sql);
	// stmt.setInt(1, member.getStudentNo());
	// stmt.setString(2, member.getName());
	// stmt.setString(3, member.getPassword());
	// stmt.setString(4, member.getDepartment());
	// stmt.setInt(5, member.getWorkType());
	// if (stmt.executeUpdate() > 0) {
	// return true;
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// return false;
	// } finally {
	// DBUtil.close(stmt);
	// }
	// return false;
	// }

	@Override
	public boolean insertStudent(Student student) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = "insert into student values(?,?,?,?,1)";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, student.getStudentNo());
			stmt.setString(2, student.getName());
			stmt.setString(3, student.getPassword());
			stmt.setString(4, student.getDepartment());
			if (stmt.executeUpdate() > 0)
				return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return false;
	}

	@Override
	public boolean insertProfessor(Professor professor) {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = "insert into professor values(?,?,?,?,2)";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, professor.getProfessorNo());
			stmt.setString(2, professor.getProName());
			stmt.setString(3, professor.getPassword());
			stmt.setString(4, professor.getDepartment());
			if (stmt.executeUpdate() > 0)
				return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return false;
	}

	// @Override
	// public Member serarchMember(int stu_number) {
	// Connection con = null;
	// PreparedStatement stmt = null;
	// ResultSet rs = null;
	// try {
	// con = DBUtil.getConnection();
	// String sql = "select student_no, name, password, department, work_type
	// from member where student_no=?";
	// stmt = con.prepareStatement(sql);
	// stmt.setInt(1, stu_number);
	// rs = stmt.executeQuery();
	// if (rs.next()) {
	// return new Member(rs.getInt("student_no"), rs.getString("name"),
	// rs.getString("password"),
	// rs.getString("department"), rs.getInt("work_type"));
	// }
	// } catch (Exception e) {
	// e.printStackTrace();
	// return null;
	// } finally {
	// DBUtil.close(rs);
	// DBUtil.close(stmt);
	// DBUtil.close(con);
	// }
	// return null;
	// }

	@Override
	public Student searchStudent(int studentNo) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			String sql = "select student_no, student_name, password, department, work_type from student where student_no=?";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, studentNo);
			rs = stmt.executeQuery();
			if (rs.next()) {
				return new Student(rs.getInt("student_no"), rs.getString("student_name"), rs.getString("password"),
						rs.getString("department"), rs.getInt("work_type"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return null;
	}

	@Override
	public Professor searchProfessor(int professorNo) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			String sql = "select professor_no, professor_name, password, department, work_type from professor where professor_no=?";
			stmt = con.prepareStatement(sql);
			stmt.setInt(1, professorNo);
			rs = stmt.executeQuery();
			if (rs.next()) {
				return new Professor(rs.getInt("professor_no"), rs.getString("professor_name"),
						rs.getString("password"), rs.getString("department"), rs.getInt("work_type"));
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
		return null;
	}

	// @Override
	// public boolean deleteMember(int stu_number) {
	// Connection con = null;
	// PreparedStatement stmt = null;
	// try {
	// con = DBUtil.getConnection();
	// String sql = "delete from member where student_no=?";
	// stmt = con.prepareStatement(sql);
	// stmt.setInt(1, stu_number);
	// if (stmt.executeUpdate() > 0)
	// return true;
	// } catch (Exception e) {
	// return false;
	// } finally {
	// DBUtil.close(con);
	// DBUtil.close(stmt);
	// }
	// return false;
	// }
	//
	// @Override
	// public Member updateMember(Member member) {
	// Connection con = null;
	// PreparedStatement stmt = null;
	// try {
	// con = DBUtil.getConnection();
	// String sql = "update member set student_no=?, name=?, password=?,
	// department=?, work_type=? where stu_number=?";
	// stmt = con.prepareStatement(sql);
	// stmt.setInt(1, member.getStudentNo());
	// stmt.setString(2, member.getName());
	// stmt.setString(3, member.getPassword());
	// stmt.setString(3, member.getDepartment());
	// stmt.setInt(4, member.getWorkType());
	//
	// if (stmt.executeUpdate() > 0)
	// return member;
	// } catch (Exception e) {
	// return null;
	// }
	// return null;
	// }

}
