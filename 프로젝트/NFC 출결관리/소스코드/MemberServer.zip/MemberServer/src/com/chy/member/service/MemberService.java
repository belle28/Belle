package com.chy.member.service;

import com.chy.member.domain.Member;
import com.chy.member.domain.Professor;
import com.chy.member.domain.Student;

public interface MemberService {
	// public boolean insertMember(Member memeber);

	public boolean insertStudent(Student student);

	public boolean insertProfessor(Professor professor);

	public Member login(int stu_number, String password);

	// public Member searchMember(int stu_number);

	public Student searchStudent(int studentNo);

	public Professor searchProfessor(int professorNo);

	// public Member updateMember(Member member);
	//
	// public boolean deleteMember(int stu_number);
}
