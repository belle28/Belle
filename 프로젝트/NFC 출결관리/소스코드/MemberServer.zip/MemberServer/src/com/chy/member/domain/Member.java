package com.chy.member.domain;

public class Member {
	private String password;
	private String department;
	private int workType;

	public Member(String password, String department, int workType) {
		super();
		this.password = password;
		this.department = department;
		this.workType = workType;
	}

	public Member() {
		super();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Member [password=");
		builder.append(password);
		builder.append(", department=");
		builder.append(department);
		builder.append(", workType=");
		builder.append(workType);
		builder.append("]");
		return builder.toString();
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public int getWorkType() {
		return workType;
	}

	public void setWorkType(int workType) {
		this.workType = workType;
	}

}
