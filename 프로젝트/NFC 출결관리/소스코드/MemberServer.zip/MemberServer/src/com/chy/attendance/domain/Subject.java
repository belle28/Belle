package com.chy.attendance.domain;

public class Subject {
	private int subjectId;
	private String subjectName;
	private int classId;
	private int day;
	private int startTime;
	private int endTime;
	private int prefessorNo;

	public Subject(int subjectId, String subjectName, int classId, int day, int startTime, int endTime,
			int prefessorNo) {
		super();
		this.subjectId = subjectId;
		this.subjectName = subjectName;
		this.classId = classId;
		this.day = day;
		this.startTime = startTime;
		this.endTime = endTime;
		this.prefessorNo = prefessorNo;
	}

	public Subject() {
		super();
	}

	public int getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(int subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public int getClassId() {
		return classId;
	}

	public void setClassId(int classId) {
		this.classId = classId;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getStartTime() {
		return startTime;
	}

	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}

	public int getEndTime() {
		return endTime;
	}

	public void setEndTime(int endTime) {
		this.endTime = endTime;
	}

	public int getPrefessorNo() {
		return prefessorNo;
	}

	public void setPrefessorNo(int prefessorNo) {
		this.prefessorNo = prefessorNo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Subject [subjectId=");
		builder.append(subjectId);
		builder.append(", subjectName=");
		builder.append(subjectName);
		builder.append(", classId=");
		builder.append(classId);
		builder.append(", day=");
		builder.append(day);
		builder.append(", startTime=");
		builder.append(startTime);
		builder.append(", endTime=");
		builder.append(endTime);
		builder.append(", prefessorNo=");
		builder.append(prefessorNo);
		builder.append("]");
		return builder.toString();
	}
}
