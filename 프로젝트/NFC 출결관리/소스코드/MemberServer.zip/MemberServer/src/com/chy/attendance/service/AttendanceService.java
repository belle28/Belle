package com.chy.attendance.service;

import java.util.ArrayList;

import com.chy.attendance.domain.MemberAttendance;
import com.chy.attendance.domain.Subject;

public interface AttendanceService {

	// �ð������� classid�� ���� subjectã��
	public Subject getSubject(int classId, String day, String time);

	// ������ȣ�� �̿��� subjectã��
	public Subject getSubject(int professorNo);

	public boolean checkStudent(int stuNumber, int subjectId);

	public int checkAttendance(Subject subject, int time);

	public boolean insertAttendance(int stuNumber, int subjectId, String regDate, int tagTime, int AttendanceType,
			String Studentname);

	public ArrayList<MemberAttendance> getCurrentAttendance(int subjectId, String currentTime);

}
