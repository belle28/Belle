package com.chy.code;

public enum AttendanceType {
	NONE(0),
	NORMAL(1),
	LATENESS(2),
	ABSENCE(3);
	

	private int code;

	private AttendanceType(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}
	

	public static AttendanceType valueOf(int code) {
		for (AttendanceType item : AttendanceType.values()) {
			if (code == item.getCode()) {
				return item;
			}
		}

		return AttendanceType.NONE;
	}
}
