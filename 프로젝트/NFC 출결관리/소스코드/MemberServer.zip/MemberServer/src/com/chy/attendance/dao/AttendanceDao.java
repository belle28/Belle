package com.chy.attendance.dao;

import java.util.ArrayList;

import com.chy.attendance.domain.MemberAttendance;
import com.chy.attendance.domain.Subject;

public interface AttendanceDao {

	public boolean checkStudent(int stuNumber, int subjectId);

	public boolean insertAttendance(int stuNumber, int subjectId, String regDate, int tagTime, int attendanceType,
			String name);

	// �ð��� ���ؼ� Subject�� �����´�...
	public Subject getSubject(int classId, int startTime, int currentTime);

	// �ش米���� ������ �����´�...
	public Subject getSubject(int professorNo);

	public ArrayList<MemberAttendance> getCurrentAttendance(int subjectId, String currentTime);
}
