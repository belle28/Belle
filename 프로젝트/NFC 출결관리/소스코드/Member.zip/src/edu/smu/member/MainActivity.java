package edu.smu.member;

import android.R.drawable;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

public class MainActivity extends Activity {

	public static final String PREFS_NAME = "LoginPrefs";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

	}

	public void login(View v) {
		Intent i = new Intent(this, LoginActivity.class);
		startActivity(i);
	}

	public void join(View v) {
		Intent i = new Intent(this, JoinActivity.class);
		startActivity(i);
	}

}
