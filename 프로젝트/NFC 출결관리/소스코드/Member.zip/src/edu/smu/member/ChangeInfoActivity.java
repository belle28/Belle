package edu.smu.member;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class ChangeInfoActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		
		//setContentView(R.layout.activity_change_student);
	
		setContentView(R.layout.activity_change_professor);
		
		
	}
	
	public void save(View v){
		Toast.makeText(this, "정보가 저장되었습니다...", Toast.LENGTH_SHORT).show();
	}
	
	public void cancel(View v){
		finish();
	}
	

	
}
