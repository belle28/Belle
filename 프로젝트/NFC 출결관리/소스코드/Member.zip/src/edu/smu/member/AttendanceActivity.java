package edu.smu.member;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


public class AttendanceActivity extends Activity {
	
	private ListView attenlist;
	

		@Override
		protected void onCreate(Bundle savedInstanceState) {
			super.onCreate(savedInstanceState);
			setContentView(R.layout.activity_attendance);
	attenlist=(ListView) findViewById(R.id.listView1);

	insertToDatabase();

		}
		



	private void insertToDatabase(){

	    class InsertData extends AsyncTask<String, Void, ArrayList<AttendList>> {
	        ProgressDialog loading;
			



	        @Override
	        protected void onPreExecute() {
	            super.onPreExecute();
	            loading = ProgressDialog.show(AttendanceActivity.this, "Please Wait", null, true, true);
	        }

	        @Override
	        protected void onPostExecute(ArrayList<AttendList> s) {
	            super.onPostExecute(s);
	           loading.dismiss();   
	   ArrayList<String> arGeneral = new ArrayList<String>();    
	 arGeneral.add(s.toString());
	            ArrayAdapter<String> adapter; 
	adapter = new ArrayAdapter<String>(AttendanceActivity.this,android.R.layout.simple_list_item_1,arGeneral);    
	        ListView list = (ListView) findViewById(R.id.listView1);
	            list.setAdapter(adapter);    
	    }

	        @Override
	        protected ArrayList<AttendList> doInBackground(String... params) {

	            try{

	                String professorno = "19982442";
	              
	                String action = "attendanceList";
	       
	                String link="http://222.118.68.230:8079/MemberServer/main.do";
	                String data  = URLEncoder.encode("professorNo", "UTF-8") + "=" + URLEncoder.encode(professorno, "UTF-8");
	                data += "&" + URLEncoder.encode("action", "UTF-8") + "=" + URLEncoder.encode(action, "UTF-8");

	               
	           
	              URL u= new URL(link);
	              HttpURLConnection huc = (HttpURLConnection) u.openConnection();
	              huc.setRequestMethod("POST");
	              huc.setDoInput(true);
	              huc.setDoOutput(true);
	              huc.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
	              OutputStream os = huc.getOutputStream();
	              os.write(data.getBytes("euc-kr"));
	              os.flush();
	              os.close();
	              BufferedReader br = new BufferedReader(new InputStreamReader(huc.getInputStream(),"UTF-8"),huc.getContentLength());
	                StringBuilder sb = new StringBuilder();                    String line = null;
	          
	                ArrayList<AttendList> attendArr=null;
	              //  DisplayAdapter disadpt=null;
	                while((line = br.readLine()) != null )
	                {
	                    sb.append(line);
	                JSONArray jsonArray = new JSONArray(line);
	                
	               attendArr = setAttendList(jsonArray);             
	                    br.close();
	                    break;
	                    
	                   
	                }
	                return attendArr;
	               
	            }
	            catch(Exception e){
	                return null;
	            }

	        }
	    }
		

	    InsertData task = new InsertData();
	    task.execute();
	}



	public ArrayList<AttendList> setAttendList(JSONArray jsonArr) throws JSONException{
		ArrayList<AttendList> attendArr = new ArrayList<AttendList>();
		
			for (int i = 0; i < jsonArr.length(); i++) {
				JSONObject jsonObj = jsonArr.getJSONObject(i);
				AttendList attendance = new AttendList(jsonObj.getString("sutdentNo"), jsonObj.getString("subjectId"),
						jsonObj.getString("regDate"), jsonObj.getString("tagTime"), jsonObj.getString("attendanceType"),
						jsonObj.getString("studentName"));
				attendArr.add(attendance);
				System.out.println(jsonObj.getString("studentName"));
			}
		System.out.println(attendArr.toString());
		return attendArr;
	}


		public class AttendList {
			private String studentNo;
			private String subjectId;
			private String regDate;
			private String tagTime;
			private String attendanceType;
			private String studentName;

			@Override
			public String toString() {
				return "학번=" + studentNo + "\n과목id=" + subjectId + "\n일시=" + regDate
						+ "\n시간=" + tagTime + "\n지각여부" + attendanceType + "\n이름=" + studentName+"\n-----------------\n";
			}

			public AttendList() {

			}

			public AttendList(String studentNo, String subjectId, String regDate, String tagTime, String attendanceType,
					String studentName) {
				super();
				this.studentNo = studentNo;
				this.subjectId = subjectId;
				this.regDate = regDate;
				this.tagTime = tagTime;
				this.attendanceType = attendanceType;
				this.studentName = studentName;
			}

			public String getStudentNo() {
				return studentNo;
			}

			public void setStudentNo(String studentNo) {
				this.studentNo = studentNo;
			}

			public String getSubjectId() {
				return subjectId;
			}

			public void setSubjectId(String subjectId) {
				this.subjectId = subjectId;
			}

			public String getRegDate() {
				return regDate;
			}

			public void setRegDate(String regDate) {
				this.regDate = regDate;
			}

			public String getTagTime() {
				return tagTime;
			}

			public void setTagTime(String tagTime) {
				this.tagTime = tagTime;
			}

			public String getAttendanceType() {
				return attendanceType;
			}

			public void setAttendanceType(String attendanceType) {
				this.attendanceType = attendanceType;
			}

			public String getStudentName() {
				return studentName;
			}

			public void setStudentName(String studentName) {
				this.studentName = studentName;
			}

		}
	}

