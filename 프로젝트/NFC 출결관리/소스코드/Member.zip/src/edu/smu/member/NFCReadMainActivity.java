package edu.smu.member;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.widget.TextView;
import android.widget.Toast;

public class NFCReadMainActivity extends Activity {

	TextView stateText, timeText, idText, nameText;
	NfcAdapter nfcAdapter;
	PendingIntent pIntent;
	IntentFilter[] filters;
	long now = System.currentTimeMillis();
	String myResult;

	Date date = new Date(now);
	SimpleDateFormat sdfNow = new SimpleDateFormat("MM/dd HH:mm:ss");
	
	String formatDate = sdfNow.format(date);
	String stuid,stuname;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_nfcread_main);

		SharedPreferences preferences = getSharedPreferences(LoginActivity.PREFS_NAME, 0);
		stuid = preferences.getString("stuid", null);
		stuname = preferences.getString("stuname", null);
		
		// timeText = (TextView) findViewById(R.id.time);
		nfcAdapter = NfcAdapter.getDefaultAdapter(this);

		if (nfcAdapter == null) {
			// NFC 誘몄��썝�떒留�
			Toast.makeText(getApplicationContext(), "NFC를 지원하지 않는 기기입니다.", Toast.LENGTH_SHORT).show();
			return;
		}

		nfcDetect();

	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();

		// Intent i = new Intent(this, AttendenceActivity.class);
		// i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
		// pIntent = PendingIntent.getActivity(this, 0, i, 0);
		Intent i = new Intent(this, this.getClass());
		i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
		pIntent = PendingIntent.getActivity(this, 0, i, 0);
		IntentFilter ndefFilter = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
		IntentFilter ndefFilter1 = new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
		IntentFilter ndefFilter2 = new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
		filters = new IntentFilter[] { ndefFilter2 };
		nfcAdapter.enableForegroundDispatch(this, pIntent, filters, null);
		// IntentFilter filter = new
		// IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
		//
		// try {
		// filter.addDataType("*/*");
		// } catch (MalformedMimeTypeException e) {
		// e.printStackTrace();
		// throw new RuntimeException("fail", e);
		// }
		//
		// filters = new IntentFilter[] { filter, };
		// nfcAdapter.enableForegroundDispatch(this, pIntent, filters, null);
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		nfcAdapter.disableForegroundDispatch(this);
	}

	// @Override
	// protected void onNewIntent(Intent intent) {
	// // TODO Auto-generated method stub
	// super.onNewIntent(intent);
	// setIntent(intent);
	// getNFCData(getIntent());
	// }
	protected void onNewIntent(Intent intent) {
		System.out.println("onNewIntent call...");
		super.onNewIntent(intent);
		setIntent(intent);
		processIntent(intent);
	}

	private void processIntent(Intent i) {

		String action = i.getAction();
		if (action.equalsIgnoreCase(NfcAdapter.ACTION_NDEF_DISCOVERED)
				|| action.equalsIgnoreCase(NfcAdapter.ACTION_TECH_DISCOVERED)
				|| action.equalsIgnoreCase(NfcAdapter.ACTION_TAG_DISCOVERED)) {

			Parcelable[] rawData = i.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
			NdefRecord[] records = ((NdefMessage) rawData[0]).getRecords();
//			 byte[] myTagType = records[0].getType();
			String tagType = new String(records[0].getType());
			byte[] myTagData = records[0].getPayload();
			System.out.println("Record Type : " + tagType);
			if (tagType.equalsIgnoreCase("T")) {
//				stateText.setText(new String(myTagData).substring(3));
//				idText.setText(stuname);
				String classid = new String(myTagData).substring(3);
				sendData(classid, stuid, stuname);
				
			} else {
				System.out.println("Unknown type �엯�땲�떎...");
			}
		}

	}

	private void sendData(String classid, String stuid,String stuname) {
		new Send().execute(stuid, classid,stuname);
	}

	class Send extends AsyncTask<String, String, String> {
		
		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if(result.equals("true")){
				Toast.makeText(NFCReadMainActivity.this, "출석되셨습니다.", Toast.LENGTH_SHORT).show();
			}else{
				
				Toast.makeText(NFCReadMainActivity.this, "결석입니다.", Toast.LENGTH_SHORT).show();
			}
		}

		@Override
		protected String doInBackground(String... params) {
			String user_stuId = (String) params[0];
			String classid = (String) params[1];
			String stu_name = (String) params[2];
			String link = "http://222.118.68.230:8079/MemberServer/main.do?action=check";
			String data = makeParameter(user_stuId, classid, stu_name);
			try {
				URL u = new URL(link);
				HttpURLConnection huc = (HttpURLConnection) u.openConnection();
				huc.setRequestMethod("POST");
				huc.setDoInput(true);
				huc.setDoOutput(true);
				huc.setUseCaches(true);
				
				BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(huc.getOutputStream(), "UTF-8"));
				huc.connect();
				System.out.println("connection..........................");
				bw.write(data);
				bw.flush();

				String str = new String();
				StringBuilder sb = new StringBuilder();
				BufferedReader br = new BufferedReader(new InputStreamReader(huc.getInputStream(), "UTF-8"));

				while ((str = br.readLine()) != null) {
					System.out.println("str : " + str);
					sb.append(str);
				}

				System.out.println("sb : " + sb.toString());
				String resultS = sb.substring(50, 54);
				System.out.println("subString : " + resultS);

				return resultS;
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
		}

		private String makeParameter(String id, String classid, String name) {
			String day=null;
			String time=null;
			if(classid.equals("406")){
				day="금";
				time="1025";
			}else if(classid.equals("404")){
				day="금";
				time = "1325";
			}
			String parameter = "studentName="+ name +"&day="+ day +"&time="+time+"&classId="+classid+"&studentNo="+id ;
			
			return parameter;
		}
	}


	public void nfcDetect() {

		if (nfcAdapter.isEnabled()) {
			onRestart();
		} else {
			System.out.println("223=====================");
			AlertDialog.Builder alt_bld = new AlertDialog.Builder(this);
			System.out.println("224=====================");
			alt_bld.setMessage("NFC를 활성화 하시겠습니까?").setCancelable(false)
					.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							// Action for 'Yes' Button
							// 4.2.2 (API 17) 遺��꽣 NFC �꽕�젙 �솚寃쎌씠 蹂�寃쎈맖.
							if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN) {
								startActivity(new Intent(android.provider.Settings.ACTION_NFC_SETTINGS));
							} else {
								startActivity(new Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS));
							}
						}
					}).setNegativeButton("No", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							// Action for 'NO' Button
							dialog.cancel();
						}
					});
			AlertDialog alert = alt_bld.create();
			// Title for AlertDialog
			alert.setTitle("Title");
			// Icon for AlertDialog
			alert.show();
		}

	}

	protected void onRestart() {
		super.onRestart();
	}
}
