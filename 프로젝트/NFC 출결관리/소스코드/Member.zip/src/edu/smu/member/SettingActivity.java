package edu.smu.member;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class SettingActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setting);
	}
	
	public void changeInfo(View v){
		Intent i = new Intent(this, ChangeInfoActivity.class);
		startActivity(i);
	}
	
	public void withdrawal(View v){
		
		//Dialog
		AlertDialog.Builder dlg = new AlertDialog.Builder(this);
		dlg.setTitle("회원탈퇴");
		dlg.setMessage("회원탈퇴하시겠습니까?");
		dlg.setIcon(android.R.drawable.ic_menu_delete);
		
		dlg.setPositiveButton("Yes", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Toast.makeText(SettingActivity.this, "회원탈퇴되었습니다...", Toast.LENGTH_SHORT).show();
				Intent i = new Intent(SettingActivity.this, MainActivity.class);
				startActivity(i);
			}
		});
		
		dlg.setNegativeButton("No", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Toast.makeText(SettingActivity.this, "취소되었습니다..", Toast.LENGTH_SHORT).show();
			}
		});
		dlg.show();
	}
	
	public void logout(View v){
		AlertDialog.Builder dlg = new AlertDialog.Builder(this);
		dlg.setTitle("로그아웃");
		dlg.setMessage("로그아웃하시겠습니까?");
		dlg.setIcon(android.R.drawable.ic_menu_help);
		
		dlg.setPositiveButton("Yes", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Toast.makeText(SettingActivity.this, "로그아웃되었습니다...", Toast.LENGTH_SHORT).show();
				Intent i = new Intent(SettingActivity.this, MainActivity.class);
				startActivity(i);
			}
		});
		
		dlg.setNegativeButton("No", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				Toast.makeText(SettingActivity.this, "취소되었습니다..", Toast.LENGTH_SHORT).show();
			}
		});
		dlg.show();
		
	}
	
	

}
