package edu.smu.member;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.json.JSONException;
import org.json.JSONObject;


import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
public class LoginActivity extends Activity implements OnClickListener{
	
	public static final String PREFS_NAME = "LoginPrefs";
	EditText idEt, passEt;

	ProgressDialog dialog = null;
	Intent loginIntent;

	String stuId = "";
	String password = "";
	
	JSONObject jsonObj;
    Member member;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
//		if (!settings.getString("pass", "").toString().equals("")) {
//			Intent intent = new Intent(LoginActivity.this, StudentActivity.class);
//			startActivity(intent);
//		}
		findViewById(R.id.loginBut).setOnClickListener(this);
		findViewById(R.id.cancelBut).setOnClickListener(this);

		idEt = (EditText) findViewById(R.id.user_id);
		passEt = (EditText) findViewById(R.id.user_password);
	
	}
	
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.loginBut:
			Toast.makeText(this, "login Btn...........", Toast.LENGTH_SHORT).show();
			login();
			break;
		default:
			break;
		}
	}

	private void login() {
		this.stuId = idEt.getText().toString();
		this.password = passEt.getText().toString();
		new Loginn().execute(stuId, password);

	}

	class Loginn extends AsyncTask<String, Void, String> {
		ProgressDialog loading;

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			loading = ProgressDialog.show(LoginActivity.this, "Please Wait", null, true, true);
		}

		@Override
		protected void onPostExecute(String s) {
			super.onPostExecute(s);
			loading.dismiss();
			// if (s.equalsIgnoreCase("student")) {
			SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
			SharedPreferences.Editor editor = settings.edit();
			if(member.getWorkType() == 1){
				editor.putString("stuid", String.valueOf(member.getNumber()));
				editor.putString("stuname",member.getName());
				editor.putString("stumajor",member.getDepartment());
//				loginIntent = new Intent(LoginActivity.this, StudentActivity.class);
//				loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//				startActivity(loginIntent);
//				System.out.println((String) jsonObj.get("name"));
			}
			editor.commit();
			// editor.putString("pass", passEt.getText().toString().trim());
			// Toast.makeText(Login.this, "Login Success",
			// Toast.LENGTH_SHORT).show();
			// Intent i = new Intent(Login.this, Student_id.class);
			// i.setFlags(i.FLAG_ACTIVITY_CLEAR_TOP |
			// i.FLAG_ACTIVITY_SINGLE_TOP);
			// startActivity(i);
			// finish();
			// } else if (s.equalsIgnoreCase("professor")) {
			// SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
			// SharedPreferences.Editor editor = settings.edit();
			// editor.putString("stuid", idEt.getText().toString().trim());
			// editor.putString("pass", passEt.getText().toString().trim());
			// editor.commit();
			// Toast.makeText(Login.this, "Login Success",
			// Toast.LENGTH_SHORT).show();
			// Intent i = new Intent(Login.this, Student_id.class);
			// startActivity(i);
			// } else {
			// Toast.makeText(Login.this, "Login Fail",
			// Toast.LENGTH_SHORT).show();
			// }
		}

		@Override
		protected String doInBackground(String... params) {

			String user_stuId = (String) params[0].trim();
			String user_password = (String) params[1].trim();

//			String link = "http://192.168.168.107:8020/MemberServer/main.do?action=login";
//			String link = "http://192.168.1.5:8020/MemberServer/main.do?action=login";
			String link = "http://222.118.68.230:8079/MemberServer/main.do?action=login";
			String data = makeParameter(user_stuId, user_password);
			try {
				URL u = new URL(link);
				HttpURLConnection huc = (HttpURLConnection) u.openConnection();
				huc.setRequestMethod("POST");
				huc.setDoInput(true);
				huc.setDoOutput(true);
				huc.setUseCaches(true);

				BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(huc.getOutputStream(), "UTF-8"));
				huc.connect();
				System.out.println("connection..........................");
				bw.write(data);
				bw.flush();

				String str = new String();
				StringBuilder sb = new StringBuilder();
				BufferedReader br = new BufferedReader(new InputStreamReader(huc.getInputStream(), "UTF-8"));

				while ((str = br.readLine()) != null) {
					System.out.println("str : " + str);
					sb.append(str);
				}

				// System.out.println("sb : " + sb.toString());
				// String resultS = sb.substring(50, 54);
				// System.out.println("subString : " + resultS);
				try {
					jsonObj = new JSONObject(sb.toString());
					if ((Integer) jsonObj.get("workType") == 2) {
						member = new Member((Integer) jsonObj.get("professorNo"), (String) jsonObj.get("proName"),
								(String) jsonObj.get("department"),
								(Integer) jsonObj.get("workType"));

					} else {
						member = new Member((Integer) jsonObj.get("studentNo"), (String) jsonObj.get("name"),
								(String) jsonObj.get("department"),
								(Integer) jsonObj.get("workType"));
					}
					System.out.println(jsonObj);
//					System.out.println("jsonObject.get(name)====" + jsonObj.getDouble("name"));
					
					int workTypeRes = member.getWorkType();

					if (workTypeRes == 1) {
						loginIntent = new Intent(LoginActivity.this, StudentActivity.class);
						loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(loginIntent);
					} else if (workTypeRes == 2) {
						Intent i = new Intent(LoginActivity.this, ProfessorActivity.class);
						i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}

				// if (resultS.equals("true")) {s
				// loginIntent = new Intent(Login.this, Student_id.class);
				// loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				// startActivity(loginIntent);
				// } else {
				// String result = "";
				// System.out.println(result);
				// }
				// return resultS;
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return null;
			// try {
			// System.out.println("136=================");
			// getPost("http://192.168.168.107:8020/MemberServer/main.do?action=login");
			// } catch (MalformedURLException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// } catch (IOException e) {
			// // TODO Auto-generated catch block
			// e.printStackTrace();
			// }
			// return "";

			// }

			// private String getPost(String url) throws MalformedURLException,
			// IOException {
			//
			// // String testUrl = "http://www.naver.com";
			// System.out.println("217 ===========80 url : " + url);
			// URLConnection uc = new URL(url).openConnection();
			// System.out.println("URLConnection ok.......");
			// uc.setDoOutput(true);
			// System.out.println("=========1");
			// OutputStreamWriter out = new
			// OutputStreamWriter(uc.getOutputStream(),
			// "UTF-8");
			// System.out.println("=========2");
			// out.write(makeParameter(stuId,password));
			// System.out.println("=========3:");
			// out.write("\r\n");
			// out.flush();
			//
			// InputStream in = uc.getInputStream();
			//
			// return "";
		}

		private String makeParameter(String id, String pass) {
			String parameter = "memberNo=" + id + "&password=" + pass;
			System.out.println("parameter : " + parameter);
			return parameter;
		}
	}


	
}
