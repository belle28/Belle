package edu.smu.member;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TabHost;

public class ProfessorActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_professor);
		
	}
	
	public void attendance(View v){
		Intent i = new Intent(this, AttendanceActivity.class);
		startActivity(i);
	}
	
	public void setting(View v){
		Intent i = new Intent(this, SettingActivity.class);
		startActivity(i);
	}

	
}
