package edu.smu.member;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class StudentMenuActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_student_menu);
	}

	public void attendance(View v) {
		Intent i = new Intent(getApplicationContext(), NFCReadMainActivity.class);
		startActivity(i);
	}

	public void setting(View v) {
		Intent i = new Intent(this, SettingActivity.class);
		startActivity(i);
	}

}
