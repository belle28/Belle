package edu.smu.member;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class JoinActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_join);
	}

	public void student(View v){
		Intent i = new Intent(this, JoinStudentActivity.class);
		startActivity(i);
	}
	
	public void professor(View v){
		Intent i = new Intent(this, JoinProfessorActivity.class);
		startActivity(i);
	}
}
