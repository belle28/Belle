package edu.smu.member;

import android.R.drawable;
import android.app.ActionBar;
import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TextView;

public class StudentActivity extends TabActivity {

	TabHost tabHost;
	Member member;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab);

		// actionBar 색바꾸기
		// ActionBar actionBar = getActionBar();
		// actionBar.setBackgroundDrawable(new
		// ColorDrawable(Color.parseColor("#35B62C")));

		// tab만들기
		tabHost = getTabHost();
		tabHost.setup();
		
		Resources res = getResources();


		TabHost.TabSpec spec;
		Intent i;

		i = new Intent(this, StudentCardActivity.class);
		//spec = tabHost.newTabSpec("tab1").setContent(i).setIndicator("", res.getDrawable(R.drawable.stu_card));
		spec = tabHost.newTabSpec("tab1").setContent(i).setIndicator("", res.getDrawable(android.R.drawable.ic_menu_edit));
		tabHost.addTab(spec);

		i = new Intent(this, StudentMenuActivity.class);
		//spec = tabHost.newTabSpec("tab2").setContent(i).setIndicator("", res.getDrawable(R.drawable.menu));
		spec = tabHost.newTabSpec("tab1").setContent(i).setIndicator("", res.getDrawable(android.R.drawable.ic_menu_send));
		tabHost.addTab(spec);

		
		
		// tab 배경색
		for (int j = 0; j < tabHost.getTabWidget().getChildCount(); j++) {
			tabHost.getTabWidget().getChildAt(j).setBackgroundColor(Color.parseColor("#000000"));
			TextView tv = (TextView) tabHost.getTabWidget().getChildAt(j).findViewById(android.R.id.title);
			tv.setTextColor(Color.parseColor("#ffffff"));
		}
		tabHost.getTabWidget().getChildAt(0).setBackgroundColor(Color.parseColor("#11000000"));
		TextView tv = (TextView) tabHost.getTabWidget().getChildAt(0).findViewById(android.R.id.title);
		tv.setTextColor(Color.parseColor("#000000"));

		
		
		// tab 클릭시 색 바꾸기
		tabHost.setOnTabChangedListener(new OnTabChangeListener() {

			@Override
			public void onTabChanged(String tabId) {
				// TODO Auto-generated method stub
				for (int j = 0; j < tabHost.getTabWidget().getChildCount(); j++) {
					tabHost.getTabWidget().getChildAt(j).setBackgroundColor(Color.parseColor("#000000"));
					//TextView tv = (TextView) tabHost.getTabWidget().getChildAt(j).findViewById(android.R.id.title);
					//tv.setTextColor(Color.parseColor("#ffffff"));
				}
				tabHost.getTabWidget().getChildAt(tabHost.getCurrentTab())
						.setBackgroundColor(Color.parseColor("#11000000"));
				//TextView tv = (TextView) tabHost.getTabWidget().getChildAt(tabHost.getCurrentTab()).findViewById(android.R.id.title);
				//tv.setTextColor(Color.parseColor("#000000"));
			}
		});

		tabHost.setCurrentTab(0);

	}

}
