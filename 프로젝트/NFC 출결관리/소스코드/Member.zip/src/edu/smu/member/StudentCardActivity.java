package edu.smu.member;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class StudentCardActivity extends Activity {
	
	TextView name,num,major;
	String stuid="";
	String stuname= "";
	String stumajor = "";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		SharedPreferences preferences = getSharedPreferences(LoginActivity.PREFS_NAME, 0);
		stuid = preferences.getString("stuid", null);
		stuname = preferences.getString("stuname", null);
		stumajor = preferences.getString("stumajor", null);
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_student_card);
		name = (TextView) findViewById(R.id.stuName);
		num = (TextView) findViewById(R.id.stuNum);
		major = (TextView) findViewById(R.id.stuMajor);
		
		name.setText(stuname);
		num.setText(stuid);
		major.setText(stumajor);
		
	}

	
	
}
